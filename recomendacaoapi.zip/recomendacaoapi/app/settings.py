class Config:
    DEBUG = True
    SECRET_KEY = 'asd'
